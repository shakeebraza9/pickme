<?php include("global.php");

global $webClass;
global $productClass;
$msg = '';
$loginReturn = $webClass->userLogin();

if($loginReturn===true){
    if(isset($_GET['ref'])){
        $reffer = $_GET['ref'];
        $loc = htmlentities(base64_decode($reffer));
    }else{
        $loc = 'profile.php';
    }

    //if user success login then refer on previous open page
    header("Location: $loc");
    exit;
}else if($loginReturn!=false){
    $msg = $loginReturn;
}

$login       =  $webClass->userLoginCheck();
if($login){
    //if user already login then go to profile
    header("Location: profile.php");
    exit();
}

include("header.php");
//var_dump($_SESSION);

@$reffer = $_SERVER['HTTP_REFERER'];
$reffer = str_replace(WEB_URL.'/','',$reffer);

if(!empty($reffer)){
    //getting reffer link and set in url, when login success page redirect on location
    if(isset($_GET['ref'])) {
        $reffer = htmlentities(base64_decode($_GET['ref']));
    }
    $reffer = base64_encode($reffer);

?>
    <script>
        $(document).ready(function(){
           history.pushState(null, "login", "?ref=<?php echo $reffer; ?>");
        });
    </script>
<?php } ?>

    <!--Inner Container Starts-->
    <div class="inner_details_container  container-fluid padding-0">
        <div class="inner_details_content standard ">
            <div class="home_links_heading h3 well well-sm"><h1 class="login_head"><?php $dbF->hardWords('My Account');?></h1></div>
            <div class="inner_content_page_div futura_bk_bt">

            <!--Login Form Start-->
                <?php if($msg!=''){ ?>
                    <div class="col-sm-12 alert alert-danger">
                        <?php echo $msg; ?>
                    </div>
                <?php } ?>

                <?php include_once(__DIR__."/signup_form.php");?>
            <!--Login Form End-->
            </div>
        </div>
    </div>

<?php include("footer.php");  ?>