<?php // include("ipcheck.php");
include("global.php");
global $dbF;

$uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri_segments = explode('/', $uri_path);

$default_lang =  defaultWebLanguage();

$segment =  $uri_segments[2];


$temp = "1";
// $sql = "SELECT * FROM seo WHERE slug = '$segment'";
// $check = $dbF->getRow($sql);


$sql_seo_slug = "SELECT seo_id FROM seo_slug WHERE slug = '$segment'";
$check_seo_slug = $dbF->getRow($sql_seo_slug);
if ($dbF->rowCount > 0){
$sql = "SELECT pageLink FROM seo WHERE id = '$check_seo_slug[seo_id]'";

}else{
$sql = "SELECT pageLink FROM seo WHERE slug = '$segment'";

}

$check = $dbF->getRow($sql);


if ($dbF->rowCount > 0) {$temp = "0";}

if (isset($temp)&&$segment!=""&&$segment!="home"&&$segment!="index.php"&&$segment!="index") {
    if ($temp == "1") {
        $p_link = "/".$segment;
    }else{
            $p_link = $check['pageLink'];

    }
    $a = explode('-', $p_link, 2);
    $key = $a[0];

    switch($key){

        case '/product':
            $_GET['pSlug'] = $a[1];
            include(__DIR__ . "/detail.php");
        break;

        case '/pCategory':
            $_GET['catSlug'] = $a[1];
            include(__DIR__ . "/products.php");
        break;

        case '/products':
            $_GET['catSlug'] = $a[1];
            include(__DIR__ . "/products.php");
        break;

        case '/productDeals':
            $_GET['catSlug'] = $a[1];
            include(__DIR__ . "/productDeals.php");
        break;

        case '/dealCategory':
            $_GET['catSlug'] = $a[1];
            include(__DIR__ . "/productDeals.php");
        break;

        case '/page':
            $_GET['page'] = $a[1];
            include(__DIR__ . "/page.php");
        break;

        case '/blog':
            $_GET['blog'] = $a[1];
            include(__DIR__ . "/blog.php");
        break;

        case '/deal':
            $_GET['dealSlug'] = $a[1];
            include(__DIR__ . "/dealDetailNew.php");
        break;

        default:

            include(__DIR__ . "/".$key.".php");
        break;
    }

}
else{

include("header.php");
global $webClass;
global $productClass;

/**
 * MultiLanguage keys Use where echo;
 * define this class words and where this class will call
 * and define words of file where this class will called
 **/
global $_e;
$_w = array();
$_w['Best Sales'] = '';
$_w['Latest Products'] = '';
$_w['Feature Products'] = '';
$_w['You Click...'] = '';
$_w['To View Other Products,'] = '';
$_w['Trending Fashion Winter 2014'] = '';
$_w['From The Blog'] = '';
$_w['Subscribe to our newsletter massa In Curabitur id risus sit quis justo sed ovanti'] = '';
$_w['Newsletter'] = '';
$_w['Social Network'] = '';
$_w['Contact Us'] = '';
$_w['Newsletter'] = '';
$_w['News and Events'] = '';
$_w['Here’s the best part of our impressive serives'] = '';
$_w['Why Choose Us?'] = '';
$_w['Please input a Value'] = '';

$_e = $dbF->hardWordsMulti($_w, currentWebLanguage(), 'Website Index');

if(isset($_SESSION['viewType'])){
unset($_SESSION['viewType']);

// var_dump("1");
}
if(isset($_SESSION['sortBy'])){
unset($_SESSION['sortBy']);

// var_dump("2");
}
if(isset($_SESSION['priceRange'])){
unset($_SESSION['priceRange']);

// var_dump("3");
}
if(isset($_SESSION['SizeFilter'])){
unset($_SESSION['SizeFilter']);

// var_dump("5");
}

if(isset($_SESSION['webUser']['sortBy'])){
unset($_SESSION['webUser']['sortBy']);

// var_dump("4");
}

if(isset($_SESSION['catId']['abcd'])){
unset($_SESSION['catId']['abcd']);

// var_dump("1");
}

?>

        <div class="banner_side">
            <div class="all1_left">
                <img src="webImages/left.png" alt="">
            </div>
            <div class="all1_right">
                <img src="webImages/right.png" alt="">
            </div>
           
                   <?php 
                         include("banner.php");
                      ?>
                <!-- banner_txt close -->
            
        </div>
        <div class="index_content">
            <div class="col_1">
                    <div class="standard">
                        <?php $box4 = $webClass->getBox('box4') ?>
                        <div class="col1_left wow fadeInRight"  >
                            <img src="<?php echo $box4['image'] ?>" alt="">
                        </div>
                        <!-- col3_left close -->
                        <div class="col1_right wow fadeInLeft animated">
                            <div class="col1_right_txt">
                                <h5><?php echo $box4['heading'] ?></h5>
                            <h1><?php echo $box4['heading2'] ?></h1>
                            <p><?php echo $box4['text'] ?></p>
                            <div class="col1_btn">
                                <a href="<?php echo $box4['link'] ?>"><?php echo $box4['linkText'] ?></a>
                            </div>
                            </div>
                        </div>
                        </div>
                        <!-- standard close -->
                        </div>
                        <!-- col1 close -->
                <div class="col_2">
                    <div class="standard">
                        <div class="col2_right wow fadeInLeft animated">
                            <div class="col2_right_txt">
                                <?php $box5 = $webClass->getBox('box5') ?>
                                <h1><?php echo $box5['heading'] ?></h1>
                                <h6><?php echo $box5['heading2'] ?></h6>
                                <?php echo $box5['text'] ?>
                                <div class="col1_btn">
                                    <a href="<?php echo $box5['link'] ?>"><?php echo $box5['linkText'] ?></a>
                                </div>
                            </div>
                        </div>
                        <!-- col2_right close -->
                        <div class="col2_left wow fadeInRight hvr-shrink animated"  >
                            <img src="<?php echo $box5['image'] ?>" alt="">
                        </div>
                        <!-- col2_left close -->
                    </div>
                </div>
                <div class="col_3">
                    <div class="standard">
                        <?php $box6 = $webClass->getBox('box6') ?>
                        <div class="col3_left wow fadeInRight hvr-shrink animated"  >
                            <img src="<?php echo $box6['image'] ?>" alt="">
                        </div>
                    <!-- col3_left close -->
                        <div class="col3_right wow fadeInLeft animated">
                            <div class="col3_right_txt">
                                <h1><?php echo $box6['heading'] ?></h1>
                            <p><?php echo $box6['text'] ?></p>
                            <div class="col1_btn">
                                <a href="<?php echo $box6['link'] ?>"><?php echo $box6['linkText'] ?></a>
                            </div>
                            </div>
                        </div>
                        <!-- col3_right close -->
                    </div>
                    <!-- standard close -->
                </div>
                <!-- col3 close -->
                <div class="col4 wow fadeInDown">
                    <div class="standard">
                        <div class="col4_left">
                <?php $locationMap = $functions->ibms_setting('locationMap'); ?>                            
                        <iframe src="<?php echo $locationMap; ?>" width="600" height="350" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </div>
                    <div class="col4_right">
                        <div class="col4_inner">
                            <?php $box7 = $webClass->getBox('box7'); ?>
                            <a href="<?php echo $box7['link'] ?>">
                                <img src="<?php echo $box7['image'] ?>" alt="">
                            <div class="col4_inner_txt">
                                <?php echo $box7['heading'] ?>
                            </div>
                            <div class="col1_btn">
                                <a href="<?php echo $box7['link'] ?>"><?php echo $box7['linkText'] ?></a>
                            </div>
                            </a>
                        </div>
                        <div class="col4_inner">
                             <?php $box8 = $webClass->getBox('box8'); ?>
                            <a href="<?php echo $box8['link'] ?>">
                                <img src="<?php echo $box8['image'] ?>" alt="">
                            <div class="col4_inner_txt">
                                <?php echo $box8['heading'] ?>
                            </div>
                            <div class="col1_btn">
                                <a href="<?php echo $box8['link'] ?>"><?php echo $box8['linkText'] ?></a>
                            </div>
                            </a>
                        </div>
                        <div class="col4_inner">
                             <?php $box9 = $webClass->getBox('box9'); ?>
                            <a href="<?php echo $box9['link'] ?>">
                                <img src="<?php echo $box9['image'] ?>" alt="">
                            <div class="col4_inner_txt">
                                <?php echo $box9['heading'] ?>
                            </div>
                            <div class="col1_btn">
                                <a href="<?php echo $box9['link'] ?>"><?php echo $box9['linkText'] ?></a>
                            </div>
                            </a>
                        </div>
                    </div>
                    </div>
                </div>
        </div>
        <!-- index_content close -->

<?php include_once(__DIR__ . "/footer.php"); 

}

?>
