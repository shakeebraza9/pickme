<?php
//for direct cart submit use orderInvoice.php?ds
//first direct submit then all avaiable payment method will show, for checkout

include("global.php");
global $webClass;
global $productClass, $functions;

$msg = $productClass->cartSubmit(); // cash on delivery

# used in header.php
define('ORDER_PAGE', TRUE);

// if ( isset($_GET['preview']) && $_GET['preview']=='1' ) {
// }


if (empty($msg)) {
if (isset($_GET['ds']) || isset($_SESSION['freeGift_ai_id'])) {
//ds Direct Submit
$msg = $productClass->cartSubmitForCheckOut(true); // first submit,
} else {
$msg = $productClass->cartSubmitForCheckOut(); // first submit,
}
}

$invoiceId = false;
if (isset($_GET['inv'])) {
$invoiceId = $_GET['inv'];
} else if ($productClass->orderLastInvoiceId != '0') {
$invoiceId = $productClass->orderLastInvoiceId;
} else if ($_SESSION['webUser']['lastInvoiceId'] !== false) {
$invoiceId = $_SESSION['webUser']['lastInvoiceId'];
} else {
//exit;
}
$_SESSION['webUser']['lastInvoiceId'] = $invoiceId;
$login = false;
if ($webClass->userLoginCheck()) {
$login = true;
}

# get number of items in invoice
$sql = "SELECT COUNT(*) FROM `order_invoice_product` WHERE `order_invoice_id` = '$invoiceId' ";
$total_order_products = $functions->dbF->getRows($sql);
$total_order_products = array_pop($total_order_products);


$cartReturned = $productClass->viewCheckOutProduct3($invoiceId);
$cartReturn = $cartReturned['temp'];
$cartCustomSizeModals = $cartReturned['sizeModal'];

$submit = $preview = $productClass->preview;
$country = $productClass->currentCountry();
include("header.php");

?>
<script>
$(document).ready(function () {
id = <?php echo $invoiceId; ?>;
history.pushState(null, "inv ", "?inv=" + id);
});
</script>
   <?php 
if(@$_SESSION['freeGift_ai_id'] && @$_SESSION['freeGift_ai_id']!=''){
	?>

	<div class="inner_content_page_div container-fluid cart3">


<div class='content_cart' id='cartViewTable'>


<div class='head_cart'>
	<h1>

<?php echo  $dbF->hardWords('Free Gift Order is Created Successfully.', false); 



$id = $functions->decode($_SESSION['freeGift_ai_id']);


$sqla = "SELECT txt_inv_id FROM `free_gift_inv` WHERE `id` = '$id' ";
$total_data_products = $dbF->getRow($sqla);

$total_data_products =$total_data_products['txt_inv_id'];
$idInv =$invoiceId;
// $sqlab = "SELECT * FROM `order_invoice_info` WHERE `order_invoice_id` = '$total_data_products' ";

 $sqlab    =   "INSERT INTO order_invoice_info(
`order_invoice_id`,
`sender_Id`,
`sender_name`,
`sender_phone`,
`sender_email`,
`sender_address`,
`sender_city`,
`sender_country`,
`sender_post`,
`receiver_name`,
`receiver_phone`,
`receiver_email`,
`receiver_address`,
`receiver_city`,
`receiver_country`,
`receiver_post`,	
`receiver_note`

)
SELECT '$idInv',
sender_Id,
sender_name,
sender_phone,
sender_email,
sender_address,
sender_city,
sender_country,
sender_post,
receiver_name,
receiver_phone,
receiver_email,
receiver_address,
receiver_city,
receiver_country,
receiver_post,	
receiver_note
FROM `order_invoice_info` WHERE order_invoice_id = '$total_data_products'";



$total_info = $dbF->setRow($sqlab);




$sql = "UPDATE free_gift_inv SET
status = '1',
new_inv = ?
WHERE id = ?";
$dbF->setRow($sql, array($idInv,$id));




  //Deduct Stock qty

            $functions->require_once_custom('orderInvoice');

            $orderInvoiceClass  =   new invoice();

            $returnStatus = $orderInvoiceClass->stockDeductFromOrder($idInv,false);

            // if($returnStatus===false){

                // throw new Exception("");

                // return false;

            // }


if(isset($_SESSION['freeGift_ai_id'])){
unset($_SESSION['freeGift_ai_id']);
}




	?>
		

	</h1></div>
</div>

</div>
   <?php }else{
?>


<style>
.inner_details_container {
background: #f0f2e5;
padding: 30px 0;
min-width: 450px;
}

.inner_details_content {
background: #fff;
padding: 0 10px;
}

.border {
border-bottom: 1px solid #ddd;
}

.paymentOptions {
display: inline-block;
width: 100%;
}

.paymentOptions img {
height: 22px;
}

.paymentOptions > div {
min-height: 30px;
padding: 5px 0;
margin: 4px;
text-align: left;
}

@media (max-width: 768px) {
.inner_details_content {
min-width: 100%;
}
}
</style>
<!--Inner Container Starts-->

<div class="inner_content_page_div container-fluid cart3">


<div class='content_cart' id='cartViewTable'>
<div class='head_cart wow fadeInDown'><h1><?php echo $_e['CHECK OUT']; ?></h1></div>
<div
class='items_cart wow fadeInDown'><?php echo $total_order_products['COUNT(*)'] . ' ' . $_e['ITEM(s)'] ?></div>

<div class='one_cart inline_block'>


<div id="first_option" class='option1 option3 wow fadeInLeft'>1. <?php echo _u($_e['Payment Option']) ?>
<div class='d_tick' style="display:none"><img src='<?php echo WEB_URL ?>/images/d_tock.png' alt=''>
</div>
</div>

<?php if ($submit == false): ?>

<div class='area_form3 wow fadeInUp'>
<div style="display:none" class='bill_text'><?php echo $_e['Billing Country']; ?></div>

<input type='hidden' class='drop_drop' disabled='' readonly='' value='SWEDEN'>

<div style="display:none" class='method_type wow fadeInLeft'>
<?php echo $_e['Payment Type']; ?>
</div><!--method_type end-->


<?php if ($invoiceId !== false && $productClass->cartInvoice) {
echo "<input type='hidden' id='invoiceId' value='$invoiceId'/>";
?>
<?php } ?>


<div class="paymentOptions">
<!--Credit Cart Option not develop now-->
<!--<div class="border radio">
<label><input type="radio" name="paymentType" value="3" class="paymentOptionRadio"><?php /*echo $productClass->productF->paymentArrayFindWeb('3'); */
?> </label>
<img src="images/creditcard.png" class="pull-right"/>
<div class="clearfix"></div>
</div>-->

<?php
$AllowKlarna = false;
//check country , kalrna not allow in some country as a payment method
//allow in sweden, norway and Finland
if ($functions->developer_setting('klarna') == '1' && preg_match('@SE|NO|FI@', $country)) {
$AllowKlarna = true;
?>
<!--Klarna Option-->
<div class="border radio">
<label><input type="radio" name="paymentType" value="2"
class="paymentOptionRadio" checked="checked" 
><?php echo $_e['Klarna = Faktura, Delbetalning, Kort & Internetbank'];
// echo $productClass->productF->paymentArrayFindWeb('2');
echo $productClass->payment_additional_price("2");
?>
</label>
<img src="images/klarna.png" class="pull-right"/>

<div class="clearfix"></div>
</div>
<?php } ?>

<?php
$AllowPaypal = false;
//check country , payson not allow in some country as a payment method
if ($login && $functions->developer_setting('paypal') == '1') {
$AllowPaypal = false;
?>
<!--PayPal Option-->
<div class="border radio">
<label><input type="radio" name="paymentType" value="1"
class="paymentOptionRadio">
<?php
echo $productClass->productF->paymentArrayFindWeb('1');
echo $productClass->payment_additional_price("1");
?>
</label>
<img src="images/paypal.png" class="pull-right"/>

<div class="clearfix"></div>
</div>
<?php } ?>

<?php
$AllowPayson = false;
//check country , payson not allow in some country as a payment method
//allow in denmark
if ($functions->developer_setting('payson') == '1' && preg_match('@DK@', $country)) {
$AllowPayson = true;
?>
<!--PayPal Option-->
<div class="border radio">
<label><input type="radio" name="paymentType" value="5"
class="paymentOptionRadio">
<?php
echo $productClass->productF->paymentArrayFindWeb('5');
echo $productClass->payment_additional_price("5");
?>

</label>
<div class="clearfix"></div>
</div>
<?php } ?>

<?php
//check country , cashOnDelivery not allow in some country as a payment method
// allow in sweden and norway
if (
($login || $functions->ibms_setting('loginForOrder') == '0')
&& $functions->developer_setting('cashOnDelivery') == '1'
) { ?>
<!--Cash on delivery Option-->
<div class="border radio">
<label><input type="radio" name="paymentType" value="0"
class="paymentOptionRadio">
<?php
echo $productClass->productF->paymentArrayFindWeb('0');
echo $productClass->payment_additional_price("0");
?>
</label>

<div class="clearfix"></div>
</div>
<?php } ?>


</div><!--paymentOptions end-->


<div class='button_area wow fadeInLeft'>
<div class='req2'></div>
<input type='submit' id="paymentOptionNext" value='<?php echo $_e['NEXT STEP']; ?>'
class='check_btn2'>
</div><!--btn_area end-->

</div><!--area_form3 end-->

<?php endif ?>


<div id="second_option" class='option1 option wow fadeInLeft'>2. <?php echo $_e['DELIVERY']; ?>
<div class='d_tick' style="display:none"><img src='<?php echo WEB_URL ?>/images/d_tock.png' alt=''>
</div>
</div>

<?php if ($submit == false): ?>

<div id='cartContinue' class=''>
<?php
if ($productClass->cartInvoice && $AllowKlarna) {
$_GET['inv'] = $invoiceId;
$_GET['ajax'] = "a";
echo "<div class='klarna_container' ";
try {
include_once('klarna.php');
} catch (Exception $e) {

}
echo "</div";
}
?>
</div>

<?php endif ?>


<div id="third_option" class='option1 option wow fadeInLeft'>3. <?php echo $_e['ORDER PREVIEW']; ?>
<div class='d_tick' style="display:none"><img src='<?php echo WEB_URL ?>/images/d_tock.png' alt=''>
</div>
</div>

<?php if ($submit):

if ($cartReturn === false && $msg == '') {
echo "<div id='EmptyCartView' class='alert alert-danger well-sm'>" . $dbF->hardWords('Error, Invoice Not Found Or You are not owner of this Invoice.', false) . "</div>";
} else {

$functions->mail_success_msg();

echo '<div style="margin-top: 15px;" class="alert alert-info" role="alert">';
if ($msg != '') {
echo $msg . ' ';
}

echo '<p style="font-size: 12px;"><a href="' . WEB_URL . '/invoicePrint?mailId=' . $invoiceId . '&orderId=' . $functions->encode($invoiceId) . '">' . $_e['Click to view your invoice OR'] . '</a><br><a href="' . WEB_URL . '/viewOrder">' . $_e['Click to view your previous orders OR'] . '</a><br>';
echo '<a href="' . WEB_URL . '/products">' . $_e['Continue Shopping'] . '</a>';
echo '</p></div>';

echo $cartReturn;
echo "<script>$('.one_cart').css('width','100%');</script>";



# google analytics ecommerce
$google_analytics_ecommerce = '<script>';
$google_analytics_ecommerce .= $webClass->generate_google_analytics_ecommerce($invoiceId);
$google_analytics_ecommerce .= 'ga(\'ecommerce:send\');';
$google_analytics_ecommerce .= '</script>';
echo $google_analytics_ecommerce;

}

endif ?>

</div><!--one_cart end-->

<?php if ($submit == false): ?>

<div class='two_cart cart_two inline_block wow fadeInUp'>
<div class='summary2'><?php echo $_e['SUMMARY']; ?></div>

<div class="sub_box34">
<div class="sub_3" style="margin-right: 10px;"><?php echo $_e['SUBTOTAL']; ?>
<!-- <img src='<?php echo WEB_URL ?>/images/question_mark.png' alt=''> -->
<div class="sub_4"><?php echo $subtotal . ' ' . $currencySymbol; ?></div>
</div>

<?php
############ 3 For 2 Category START #########
global $three_for_2_minus_price;
$three_for_2_cat_div = '';
if($three_for_2_minus_price > 0){
$three_for_2_cat_div = "
<div class='sub_3'  style='margin-right: 10px;'>".$_e['Three For Two Category']."
<div class='sub_4'>$three_for_2_minus_price $currencySymbol</div>
</div>";
}
echo $three_for_2_cat_div;
############ 3 For 2 Category END #########
?>



<div class="sub_3" style="margin-right: 10px;">
<?php echo $_e['ESTIMATED DELIVERY & HANDLING']; ?>
<div
class="sub_4"><?php echo "<span class='pShippingPriceTemp' data-real='$shipPrice'>$shipPrice</span>" . ' ' . $currencySymbol; ?></div>
</div>
</div>


<!--
<div class='sub_box34'>
<div class='sub_3' style="margin-right: 10px;" ><?php echo $_e['SUBTOTAL']; ?>
<img src='<?php echo WEB_URL ?>/images/question_mark.png' alt=''>
</div>
<div class='sub_4'><?php echo $subtotal . ' ' . $currencySymbol; ?></div>
<div class='sub_3'><?php echo $_e['ESTIMATED DELIVERY & HANDLING']; ?></div>
<div class='sub_4'><?php echo $shipPrice . ' ' . $currencySymbol; ?></div>
</div> sub_box34 end-->

<div class='tc_line2'></div>

<div class='sub_box34'>
<div class='sub_3 sub_font3'><?php echo $_e['TOTAL']; ?></div>
<div
class='sub_4 sub_font4 '><?php echo "<span class='pGrandTotal' data-total='$grandTotal'>$grandTotal </span>" . ' ' . $currencySymbol; ?></div>
</div><!--sub_box34 end-->

<?php # IN YOUR CART
$box = $webClass->getBox('box9');
?>
<div class='summary2'><?php echo $box['heading']; ?></div>
<div class='arrive'><?php echo $box['text']; ?></div>


<div class="cart2">
<?php
if ($msg != '') {
echo '<div class="alert alert-info" role="alert">' . $msg . '</div>';
}
?>

<?php
if ($cartReturn === false && $msg == '') {
echo "<div id='EmptyCartView' class='alert alert-danger well-sm'>" . $dbF->hardWords('Error, Invoice Not Found Or You are not owner of this Invoice.', false) . "</div>";
} else {
echo $cartReturn;
}
?>


</div>
<!--Cart2 end-->


<?php # NEED HELP? BOX
$box = $webClass->getBox('box10');
?>



</div><!--two_cart end-->


<?php endif ?>


</div>   <!--content_cart end-->


<?php echo $cartCustomSizeModals; ?>


</div><!--inner_content_page_div end-->

<?php } ?>
<?php include("footer.php"); ?>

<style>
.overlay_cart {
    position: absolute;
    top: 5%;
    right: 0;
    z-index: 1000;
    background: #FFF;        
}

.removeCartproduct_2017 {
    width: 22px;
    height: 22px;
    background: #edefec;
    border-radius: 50px;
    text-align: center;
    padding: 2px 0;
    cursor: pointer;
    position: absolute;
    left: 0px;
    top: 55px;
}
</style>

   <style type="text/css">
.cart3 {
    padding: 10px;
    display: block !important;
    background: #fff;
    max-width: 1200px;
    margin: 0 auto;
    margin-bottom: 50px;
}
     
     .cart3 .for_cart3 {
         display: block;
     }
     
     .cart3 .couponCode label.control-label,
     .cart3 .giftCard_formDiv label.control-label {
         width: 100%;
         font-weight: normal;
         text-align: left;
     }
     
     .cart3 .couponCode,
     .cart3 .giftCard_formDiv {
         color: #fff;
     }
     
     .cart3 .head_cart {
         color: #333333;
         text-align: center;
         font-size: 36px;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         overflow: hidden;
     }
     
     .cart3 .items_cart {
         color: #939191;
         text-align: center;
         font-size: 17px;
         font-family: 'Titillium Web', sans-serif;
         height: 23px;
         overflow: hidden;
     }
     
.cart3 .one_cart {
    width: 64%;
    height: auto;
    /* margin-top: 2%; */
    display: inline-block;
    vertical-align: top;
}
     
     .cart3 .oc_head {
         height: 80px;
         width: 100%;
         background: #ebebeb;
         padding: 15px;
     }
     
     .cart3 .oc_heading {
         color: #7cbe35;
         font-size: 14px;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
     }
     
     .cart3 .oc_text {
         font-size: 15px;
         height: 20px;
         overflow: hidden;
         color: #262626;
         font-style: italic;
         font-family: 'Titillium Web', sans-serif;
     }
     
     .cart3 .oc_text a {
         color: #7cbe35;
         text-decoration: underline;
     }
     
     .cart3 .oc_text a:hover {
         color: #7cbe35;
     }
     
     .cart3 .detail_cart {
         width: 100%;
         overflow: hidden;
         margin-top: 3%;
     }
     
     .cart3 .detail_img {
         width: 119px;
         height: 126px;
     }
     
     .cart3 .detail_img img {
         width: 100%;
     }
     
     .cart3 .info_cart {
         width: 369px;
         overflow: hidden;
         margin-left: 12px;
     }
     
     .cart3 .info_head {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-size: 15px;
         /* height: 21px;*/
         overflow: hidden;
         font-weight: 600;
         margin-bottom: 9px;
     }
     
     .cart3 .info_text {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         line-height: 14px;
         text-shadow: 0 0 0 #262626;
     }
     
     .cart3 .info_text label {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         font-weight: 600;
         width: 53px;
         margin-right: 12px;
     }
     
     .cart3 .info_btn {
         display: inline-block;
         vertical-align: top;
         width: 167px;
         height: 43px;
         line-height: 43px;
         border: 0;
         text-align: center;
         border-bottom: 2px solid #7cbe35;
         background: #ededed;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         margin-right: 10px;
         border-radius: 5px;
         color: #333333;
         font-size: 16px;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
         margin-top: 23px;
     }
     
     .cart3 .info_btn:hover {
         border-bottom: 2px solid #333333;
         color: #7cbe35;
         font-weight: 600;
     }
     
     .cart3 .rate_detail {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         width: 106px;
         height: 20px;
         font-size: 18px;
         float: right;
         text-align: right;
         text-shadow: 0 0 0 #262626;
         overflow: hidden;
     }
     
.cart3 .two_cart {
    width: 33%;
    height: auto;
    margin-top: 2%;
    background: #363636;
    margin-left: 25px;
    display: inline-block;
    vertical-align: top;
}
     
     .cart3 .tc_line {
         width: 100%;
         height: 3px;
         background: url(../images/line.png);
     }
     
     .cart3 .summary {
         color: #fff;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         width: 100%;
         height: 65px;
         line-height: 65px;
         padding-left: 20px;
         padding-right: 20px;
         font-size: 24px;
     }
     
     .cart3 .promo-code {
         width: 100%;
         padding: 20px;
     }
     
     .cart3 .pc_text {
         color: #fff;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
     }
     
     .cart3 .pc_field {
         display: inline-block;
         vertical-align: top;
         width: 171px;
         height: 33px;
         border: 1px solid transparent;
         border: 0;
         border-radius: 5px;
         background: #fff;
         margin-top: 14px;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
         margin-right: 6px;
     }
     
     .cart3 .pc_field:hover {
         background: #fff;
         border: 1px solid #7cbe35;
         box-shadow: inset 0px 0px 4px #7cbe35;
         color: #7cbe35;
     }
     
     .cart3 .apply {
         display: inline-block;
         vertical-align: top;
         width: 97px;
         height: 33px;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
         text-shadow: 0 0 0 #fff;
         border: 0;
         border: 1px solid transparent;
         border-radius: 5px;
         background: #ebebeb;
         margin-top: 14px;
         font-family: 'Titillium Web', sans-serif;
         color: #333333;
         font-size: 14px;
     }
     
     .cart3 .apply:hover {
         background: #fff;
         border: 1px solid #7cbe35;
         box-shadow: inset 0px 0px 4px #7cbe35;
         color: #7cbe35;
     }
     
     .cart3 .sub_box {
         width: 100%;
         padding-left: 20px;
         padding-right: 20px;
         padding-top: 14px;
         position: relative;
         padding-bottom: 14px;
     }
     
     .cart3 .sub_1 {
         font-family: 'Titillium Web', sans-serif;
         color: #fff;
         font-size: 12px;
         width: 226px;
         display: inline-block;
     }
     
     .cart3 .sub_1 img {
         margin-top: -3px;
         margin-left: 1px;
     }
     
     .cart3 .sub_2 {
         font-family: 'Titillium Web', sans-serif;
         color: #fff;
         font-size: 12px;
         text-align: right;
         display: inline-block;
         float: right;
         clear: both;
     }
     
     .cart3 .sub_font {
         font-size: 23px;
         width: auto;
     }
     
     .cart3 .sub_font img {
         margin-right: 4px;
     }
     
     .cart3 .checkout {
         width: 100%;
         padding: 0;
         height: 41px;
         line-height: 41px;
         text-align: center;
         color: #fff;
         border: 0;
         border: 1px solid transparent;
         border-radius: 5px;
         font-family: 'Titillium Web', sans-serif;
         font-size: 15px;
         background: #7cbe35;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
     }
     
     .cart3 .checkout:hover {
         background: #fff;
         border: 1px solid #7cbe35;
         box-shadow: inset 0px 0px 4px #7cbe35;
         color: #7cbe35;
     }
     
     .cart3 .text_sub {
         font-family: 'Titillium Web', sans-serif;
         color: #fff;
         font-size: 13px;
         margin-top: 16px;
     }
     
     .cart3 .sub_font1 {
         font-size: 18px;
         width: auto;
     }
     
     .cart3 .sub_font1 img {
         margin-right: 4px;
     }
     
     .cart3 .help_area {
         position: relative;
         margin-top: 50px;
     }
     
     .cart3 .help_head {
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         color: #333333;
         font-size: 20px;
     }
     
     .cart3 .help_points {
         margin-top: 12px;
     }
     
     .cart3 .help_points ul li {
         line-height: 19px;
     }
     
     .cart3 .help_points ul li span {
         margin-right: 10px;
     }
     
     .cart3 .help_points ul li a {
         font-size: 13px;
         color: #767676;
         font-family: 'Titillium Web', sans-serif;
         text-decoration: underline;
     }
     
     .cart3 .help_points ul li a:hover {
         color: #7cbe35;
         text-decoration: none;
     }
     
     .cart3 .more {
         font-size: 13px;
         color: #767676;
         font-family: 'Titillium Web', sans-serif;
         text-decoration: underline;
         margin-top: 20px;
     }
     
     .cart3 .more a {
         font-size: 13px;
         color: #767676;
         font-family: 'Titillium Web', sans-serif;
         text-decoration: underline;
     }
     
     .cart3 .more:hover {
         color: #7cbe35;
         text-decoration: none;
     }
     
     .cart3 .option1 {
         width: 100%;
         min-height: 58px;
         line-height: 58px;
         padding-left: 20px;
         background: #363636;
         color: #fff;
         font-family: 'Titillium Web', sans-serif;
         font-size: 23px;
         font-weight: 600;
         position: relative;
     }
     
     .cart3 .option {
         background: #ebebeb;
         margin-top: 20px;
         color: #333333;
     }
     
     .cart3 .option3 {
         margin-top: 20px;
     }
     
     .cart3 .area_form {
         background: #ebebeb;
         padding: 20px;
     }
     
     .cart3 .form1 {
         border: 1px solid #d8d8d8;
         background: #d8d8d8;
         padding-left: 20px;
         background: #fff;
         padding-top: 26px;
         padding-bottom: 26px;
         padding-right: 20px;
     }
     
     .cart3 .form_fill {
         margin-top: 12px;
     }
     
     .cart3 .form_text {
         display: inline-block;
         vertical-align: top;
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 13px;
         width: 130px;
         max-width: 200px;
         height: 36px;
         line-height: 36px;
     }
     
     .cart3 .form_text span {
         color: #e01b22;
     }
     
     .cart3 .form_field {
         display: inline-block;
         vertical-align: top;
         width: 280px;
         height: 36px;
         border: 1px solid #e8e8e8;
         font-family: 'Titillium Web', sans-serif;
         border-radius: 5px;
         margin-left: 8px;
         background: #fff;
         transition: .7s;
         padding-left: 10px;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
     }
     
     .cart3 .form_field:hover {
border: 1px solid #d19552;
    box-shadow: inset 0px 0px 4px #d19552;
    color: #212121;
     }
     
     .cart3 .form_field:focus {
         outline: 0;
     }
     
     .cart3 .address {
         height: 78px;
     }
     
     .cart3 .form_text2 {
         margin-left: 8px;
     }
     
     .cart3 .form_text2 img {
         margin-top: -4px;
     }
     
     .cart3 .form_text3 {
         width: auto;
     }
     
     .cart3 .form_text3 img {
         margin-top: -4px;
     }
     
     .cart3 .form_fill2 {
         margin-top: 10px;
     }
     
     .cart3 .method {
         font-size: 14px;
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         margin-top: 2px;
     }
     
     .cart3 .method input[type=radio] {
         display: none;
     }
     
     .cart3 .method label {
         margin-right: 9px;
         font-size: 14px;
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
     }
     
     .cart3 .method label span {
         color: #7cbe35;
         font-size: 14px;
         font-family: 'Titillium Web', sans-serif;
     }
     
     .cart3 input[type=radio] + label:before {
         content: "";
         display: inline-block;
         width: 15px;
         height: 15px;
         vertical-align: middle;
         margin-right: 8px;
         background-color: #fff;
         border-radius: 8px;
         border: 1px solid #dadada;
     }
     
     .cart3 input[type=checkbox] + label:before {
         content: "";
         display: inline-block;
         width: 15px;
         height: 15px;
         vertical-align: middle;
         margin-right: 8px;
         background-color: #fff;
         border-radius: 4px;
     }
     
     .cart3 input[type=radio]:checked + label:before {
         content: "";
         color: white;
         background-color: #fff;
         font-size: 1.8em;
         text-align: center;
         line-height: 14px;
         text-shadow: 0px 0px 3px #eee;
         border: 5px solid #7cbe35;
     }
     
     .cart3 .form2 {
         border: 1px solid #d8d8d8;
         background: #d8d8d8;
         padding-left: 20px;
         height: 90px;
         background: #fff;
         padding-top: 20px;
         padding-bottom: 26px;
         margin-top: 20px;
     }
     
     .cart3 .checkbox_form {
         display: inline-block;
         vertical-align: top;
     }
     
     .cart3 .checkbox_text {
         display: inline-block;
         vertical-align: top;
         width: auto;
         color: #333333;
         font-size: 13px;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
     }
     
     input[type="checkbox"] {
         margin: 2px 0px 0px;
     }
     
     .cart3 .note {
         color: #333333;
         font-size: 14px;
         font-family: 'Titillium Web', sans-serif;
         margin-top: 10px;
         text-shadow: 0 0 0 #333333;
     }
     
     .cart3 .note a {
         color: #7cbe35;
         text-decoration: underline;
     }
     
     .cart3 .note a:hover {
         color: #333333;
         text-shadow: 0 0 0 #333333;
     }
     
     .cart3 .button_area {
         margin-top: 20px;
         position: relative;
         height: 76px;
     }
     
     .cart3 .req {
         color: #333333;
         font-size: 14px;
         font-family: 'Titillium Web', sans-serif;
         display: inline-block;
         vertical-align: top;
         text-shadow: 0 0 0 #333333;
         width: 200px;
     }
     
     .cart3 .req span {
         color: #e01b22;
     }
     
     .cart3 .req2 {
         color: #333333;
         font-size: 14px;
         font-family: 'Titillium Web', sans-serif;
         display: inline-block;
         vertical-align: top;
         text-shadow: 0 0 0 #333333;
         width: 200px;
     }
     
     .cart3 .req2 span {
         color: #28c891;
     }
     
     .cart3 .check_btn2 {
         float: right;
         clear: both;
         display: inline-block;
         vertical-align: top;
         width: 165px;
         border-radius: 5px;
         height: 51px;
         border: 1px solid transparent;
         line-height: 51px;
         text-align: center;
         color: #fff;
         font-size: 16px;
         font-family: 'Titillium Web', sans-serif;
         background: #8f013d;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
     }
     
.cart3 .check_btn2:hover {
    border: 1px solid #ffffff;
    box-shadow: inset 0px 0px 10px #ffffff;
    color: #d3d3d3;
}
     
     .cart3 .cart_two {
         background: none;
     }
     
     .cart3 .summary2 {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         width: 100%;
         height: 65px;
         background: #ebebeb;
         line-height: 65px;
         padding-left: 20px;
         padding-right: 20px;
         font-size: 24px;
     }
     
     .cart3 .sub_box34 {
         width: 100%;
         padding-top: 14px;
         position: relative;
         padding-bottom: 14px;
     }
     
     .cart3 .sub_3 {
         font-family: 'Titillium Web', sans-serif;
         color: #333333;
         font-size: 12px;
         display: inline-block;
         font-weight: bold;
         margin-top: 7px;
         width: 100%;
     }
     
     .cart3 .sub_3 img {
         margin-top: -3px;
         margin-left: 1px;
     }
     
     .cart3 .sub_4 {
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 12px;
         color: #333333;
         text-align: right;
         display: inline-block;
         margin-top: 7px;
         float: right;
         clear: both;
         min-width: 55px;
     }
     
     .cart3 .tc_line2 {
         width: 100%;
         height: 1px;
         background: #dfdfdf;
     }
     
     .cart3 .sub_font3 {
         font-size: 20px;
         width: auto;
     }
     
     .cart3 .sub_font4 {
         font-size: 20px;
         width: auto;
         color: #8f013d;
     }
     
     .cart3 .arrive {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         width: 100%;
         line-height: 41px;
         padding-left: 20px;
         padding-right: 20px;
         font-size: 20px;
     }
     
     .cart3 .detail_cart2 {
         width: 100%;
         height: auto;
         overflow: hidden;
         margin-top: 3%;
     }
     
     .cart3 .detail_img2 {
         width: 63px;
         height: 69px;
     }
     
     .cart3 .detail_img2 img {
         width: 100%;
     }
     
.cart3 .info_cart2 {
    width: 75%;
    height: auto;
    overflow: hidden;
    margin-left: 6px;
    padding-bottom: 4%;
    display: inline-block;
    vertical-align: top;
}
     
     .cart3 .info_head2 {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         height: 21px;
         overflow: hidden;
         font-weight: 600;
         margin-bottom: 9px;
     }
     
     .cart3 .info_head2 a {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
     }
     
     .cart3 .info_text2 {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         line-height: 14px;
         text-shadow: 0 0 0 #262626;
     }
     
     .cart3 .info_text2 label {
         color: #262626;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 14px;
         /*width: 100%;*/
         margin-right: 12px;
     }
     
     .cart3 .rate_detail2 {
         color: #8f013d;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 14px;
         width: 106px;
         height: 20px;
         margin-top: 16px;
         overflow: hidden;
     }
     
     .cart3 .area_form2 {
         padding-top: 25px;
         padding-left: 20px;
         padding-bottom: 40px;
         padding-right: 20px;
     }
     
     .cart3 .member {
         margin-top: 6%;
         width: 50%;
     }
     
     .cart3 .member_head {
         color: #333333;
         font-size: 19px;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         margin-bottom: 30px;
     }
     
     .cart3 .m_form_fill {
         margin-top: 10px;
     }
     
     .cart3 .m_form_text {
         display: inline-block;
         vertical-align: top;
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 13px;
         width: 108px;
         height: 34px;
         line-height: 34px;
     }
     
     .cart3 .m_form_field {
         display: inline-block;
         vertical-align: top;
         width: 197px;
         height: 34px;
         border: 1px solid #e8e8e8;
         font-family: 'Titillium Web', sans-serif;
         border-radius: 5px;
         margin-left: 8px;
         background: #fff;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
     }
     
     .cart3 .m_form_field:hover {
         background: #fff;
         border: 1px solid #7cbe35;
         box-shadow: inset 0px 0px 4px #7cbe35;
         color: #7cbe35;
     }
     
     .cart3 .form_field:focus {
         outline: 0;
     }
     
     .cart3 .pass_help {
         margin-top: 11%;
     }
     
     .cart3 .pass_help a {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         text-decoration: underline;
     }
     
     .cart3 .pass_help a:hover {
         color: #7cbe35;
         text-decoration: none;
     }
     
     .cart3 .help2 {
         margin-top: 3%;
     }
     
     .cart3 .help2 a {
         color: #b1b1b1;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         text-decoration: underline;
     }
     
     .cart3 .help2 a:hover {
         color: #7cbe35;
         text-decoration: none;
     }
     
     .cart3 .guest {
         margin-top: 6%;
         width: 45%;
         margin-left: 27px;
     }
     
     .cart3 .g_top {
         margin-bottom: 36px;
     }
     
     .cart3 .guest_text {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-size: 13px;
         text-shadow: 0 0 0 #333333;
         margin-top: 6px;
         display: flex;
     }
     
     .cart3 .gg {
         margin-right: 9px;
         width: 6px;
         height: 7px;
         display: flex;
         margin-top: 5px;
     }
     
     .cart3 .cb {
         float: none;
         margin-top: 8%;
         width: 188px;
         margin-right: 10px;
     }
     
     .cart3 .form3 {
         height: 294px;
     }
     
     .cart3 .form_fill_3 {
         margin-top: 10px;
     }
     
     .cart3 .form_text_3 {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 14px;
         width: 108px;
         height: 36px;
         line-height: 36px;
     }
     
     .cart3 .form_text_3 span {
         color: #28c891;
         margin-left: 4px;
     }
     
     .cart3 .form_field_3 {
         display: inline-block;
         vertical-align: top;
         width: 278px;
         height: 36px;
         border: 1px solid #e8e8e8;
         font-family: 'Titillium Web', sans-serif;
         border-radius: 5px;
         background: #fff;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
     }
     
     .cart3 .form_field_3:hover {
         background: #fff;
         border: 1px solid #7cbe35;
         box-shadow: inset 0px 0px 4px #7cbe35;
         color: #7cbe35;
     }
     
     .cart3 .form_field_3:focus {
         outline: 0;
     }
     
     .cart3 .form_text_3_1 {
         display: inline-block;
         vertical-align: top;
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-size: 13px;
         width: 292px;
         height: 36px;
         margin-left: 14px;
     }
     
     .cart3 .d_tick {
         position: absolute;
         right: 2%;
         top: 0;
     }
     
     .cart3 .area_form3 {
         padding-top: 25px;
         padding-left: 20px;
         padding-bottom: 20px;
         padding-right: 20px;
         background: #ebebeb;
     }
     
     .cart3 .bill_text {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-size: 13px;
         font-weight: 600;
         height: 37px;
         overflow: hidden;
     }
     
     .cart3 .bill_text span {
         font-size: 13px;
         font-weight: normal;
     }
     
     .cart3 .drop_drop {
         border: 1px solid #c8c8c8;
         box-shadow: 0px 2px 3px #c8c8c8;
         background: rgba(244, 244, 244, 1);
         background: -moz-linear-gradient(top, rgba(244, 244, 244, 1) 0%, rgba(242, 242, 242, 1) 19%, rgba(240, 240, 240, 1) 39%, rgba(239, 239, 239, 1) 65%, rgba(236, 236, 236, 1) 89%, rgba(236, 236, 236, 1) 100%);
         background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(244, 244, 244, 1)), color-stop(19%, rgba(242, 242, 242, 1)), color-stop(39%, rgba(240, 240, 240, 1)), color-stop(65%, rgba(239, 239, 239, 1)), color-stop(89%, rgba(236, 236, 236, 1)), color-stop(100%, rgba(236, 236, 236, 1)));
         background: -webkit-linear-gradient(top, rgba(244, 244, 244, 1) 0%, rgba(242, 242, 242, 1) 19%, rgba(240, 240, 240, 1) 39%, rgba(239, 239, 239, 1) 65%, rgba(236, 236, 236, 1) 89%, rgba(236, 236, 236, 1) 100%);
         background: -o-linear-gradient(top, rgba(244, 244, 244, 1) 0%, rgba(242, 242, 242, 1) 19%, rgba(240, 240, 240, 1) 39%, rgba(239, 239, 239, 1) 65%, rgba(236, 236, 236, 1) 89%, rgba(236, 236, 236, 1) 100%);
         background: -ms-linear-gradient(top, rgba(244, 244, 244, 1) 0%, rgba(242, 242, 242, 1) 19%, rgba(240, 240, 240, 1) 39%, rgba(239, 239, 239, 1) 65%, rgba(236, 236, 236, 1) 89%, rgba(236, 236, 236, 1) 100%);
         background: linear-gradient(to bottom, rgba(244, 244, 244, 1) 0%, rgba(242, 242, 242, 1) 19%, rgba(240, 240, 240, 1) 39%, rgba(239, 239, 239, 1) 65%, rgba(236, 236, 236, 1) 89%, rgba(236, 236, 236, 1) 100%);
         filter: progid: DXImageTransform.Microsoft.gradient( startColorstr='#f4f4f4', endColorstr='#ececec', GradientType=0);
         width: 169px;
         color: #333333;
         font-size: 13px;
         font-family: 'Titillium Web', sans-serif;
         padding-left: 9px;
         height: 34px;
         border-radius: 5px;
         margin-top: 3%;
         outline: 0;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
     }
     
     .cart3 .method_type {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 18px;
         /*margin-top: 7%;*/
         margin-bottom: 1%;
     }
     
     .cart3 .tick3 {
         height: 2px;
         width: 100%;
         background: url(../webImages/l_small.png) repeat;
     }
     
     .cart3 .card {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 14px;
         padding-top: 12px;
         padding-bottom: 12px;
     }
     
     .cart3 .card span {
         margin-right: 10px;
     }
     
     .cart3 .billing_area {
         background: #fff;
         height: 442px;
         overflow: hidden;
         padding-top: 25px;
         padding-left: 20px;
         padding-bottom: 20px;
         margin-top: 10px;
         border: 1px solid #c6c6c6;
     }
     
     .cart3 .billing_text {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 600;
         font-size: 18px;
     }
     
     .cart3 .bb {
         height: 1px;
         margin-top: 2%;
         margin-bottom: 3%;
         width: 100%;
         background: #dedede;
     }
     
     .cart3 .bill_add {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         width: 30%;
         margin-top: 10px;
     }
     
     .cart3 .bill_add span {
         color: #333333;
         font-family: 'Titillium Web', sans-serif;
         font-size: 14px;
         font-weight: 600;
     }
     
     .cart3 .form_form {
         display: block;
     }
     
     .cart3 .form_form span {
         color: #e01b22;
     }
     
     .cart3 .btn2_logout {
         background: url(../webImages/btn2_logout.png) no-repeat;
     }
     
     .cart3 .psort_label {
         vertical-align: top;
         padding: 0;
         display: inline-block;
         line-height: normal;
         margin-top: 10px;
         margin-right: 10px;
         text-align: right;
     }
     
     .cart33 .size_in_divs {
         width: 39px;
         height: 35px;
         border: 1px solid #afafaf;
         line-height: 31px;
         text-align: center;
         margin-top: 5px;
         display: inline-block;
         vertical-align: top;
         margin-right: 10px;
         background: #fff;
         color: #333333;
         font-size: 14px;
         font-family: 'Titillium Web', sans-serif;
         font-weight: 300;
         transition: .7s;
         -webkit-transition: .7s;
         -moz-transition: .7s;
         -o-transition: .7s;
         -webkit-appearance: button;
         cursor: pointer;
     }
     
     .cart33 .size_in_divs:hover {
         background: #7cbe35;
         border: 1px solid #7cbe35;
         color: #fff;
     }
     
     .cart33 .size_in_divs label {
         display: block;
         padding: 1px 13px;
     }
     
     .cart3 .bgColorActive {
         display: inline-block;
     }
     
     .cart3 .bgColorActive label {
         height: 24px;
     }
     
     .cart3 .bgColorActive label .colors_in_divs {
         border: 0px solid #f1f1f1;
     }
     
     .cart3 .inner_details_content {
         width: auto;
     }
     
     .cart3 .reload_btn {
         display: inline-block;
         vertical-align: top;
         margin-top: 30px;
         width: 120px;
         height: 43px;
     }
     
     .cart3 .addByQtyBtn {
         margin: 0;
         margin-top: 30px;
     }
     
     .cart3 .img_detail {
         width: 119px;
         height: 126px;
     }
     
     .cart3 .img_detail img,
     .img_detail2 img {
         max-width: 100%;
         max-height: 100%;
     }
     
.cart3 .img_detail2 {
    width: 63px;
    height: 69px;
    overflow: hidden;
    display: inline-block;
    vertical-align: top;
}
     
     .cart3 #custom_size_button {
         width: auto;
     }
     
     .cart3 .productRadioHidden:checked + .bgSizeActive label {
         padding: 1px 13px;
     }
     
     .cart3 .sender_countryFieldset {
         display: inline;
     }
     
     .cart3 .klarna_container {
         padding: 30px;
     }
     
     .cart3 .form_fill textarea {
         height: 70px;
         resize: none;
     }
     
     .cart3 #size_radio label {
         height: 33px;
         border: none;
         box-shadow: none;
         -webkit-box-shadow: none;
     }
     
     .cart3 .checkout_scale {
         margin-bottom: 10px;
     }
     
     .cart3 .checkout_scale label {
         padding: 6px 13px !important;
     }
     
     .cart3 .header1 {
         display: none;
     }
     
     .cart3 .mm-menu {
         background: #444 !important;
     }
     
     .cart3 .mm-subopened .mm-subblocker {
         opacity: 1;
     }
     
     .cart3 .mm-subopened .mm-subblocker:before {
         content: "x";
         color: #fff;
         display: inline-block;
         padding: 5px 15px;
     }
     
     .cart3 .mm-subopened .mm-subblocker:hover:before {
         color: #ccc;
     }
     
     .cart3 #cartContinue,
     #receiver_area {
         /*display: none;*/
     }
     
     .cart3 .shipping_text {
         font-family: 'Titillium Web', sans-serif;
         font-weight: 300;
     }
     
     .cart3 .option1 {
         width: 100%;
         min-height: 58px;
         line-height: 58px;
         padding-left: 20px;
         background: #363636;
         color: #fff;
         font-family: 'Titillium Web', sans-serif;
         font-size: 23px;
         font-weight: 600;
         position: relative;
     }
     
     .cart3 .option {
         background: #ebebeb;
         margin-top: 20px;
         color: #333333;
     }
     
     .cart3 .option3 {
         /*margin-top: 20px;*/
     }
     
     .cart3 .area_form {
         background: #ebebeb;
         padding: 20px;
     }

}
        </style>