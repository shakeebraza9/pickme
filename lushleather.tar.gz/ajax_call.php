<?php

include(__DIR__."/_models/functions/products_ajax_functions.php");
exit;