<?php include("global.php");
global $webClass;

if($seo['title']==''){
    $seo['title'] = 'User Profile';
}
$login = $webClass->userLoginCheck();
if(!$login){
    header('Location: login');
    exit();
}

$msg = $webClass->webUserEditSubmit();
include("header.php");
?>

    <!--Inner Container Starts-->
    <div class="container-fluid padding-0">
        <div class="standard">
            <?php
                if(isset($_GET['page'])){ echo '<div class="home_links_heading h3 well well-sm">';
                    echo htmlentities($_GET['page']);
                    echo "</div>";
                }
            ?>
            <div class="inner_content_page_div container-fluid">

                <?php
                    if(!isset($_GET['page'])){
                ?>

                    <div class="col-sm-2 text-center padding-0">
                       <a href="<?php echo WEB_URL;?>/profile?page=Profil">
                           <img src="<?php echo WEB_URL;?>/images/profile.png" width="90">
                           <div><?php $dbF->hardWords('Customer Profile'); ?></div>
                       </a>
                   </div>

                   <?php if($functions->developer_setting('cartSystem') == '1'){ ?>
                       <div class="col-sm-2 text-center padding-0">
                           <a href="<?php echo WEB_URL;?>/viewOrder">
                               <img src="<?php echo WEB_URL;?>/images/cartorder.png" width="90">
                               <div><?php $dbF->hardWords('Orders');?></div>
                           </a>
                       </div>
                   <?php } ?>

                   <?php if($functions->developer_setting('return_Product_from_client') == '1'){ ?>
                       <div class="col-sm-2 text-center padding-0">
                           <a href="<?php echo WEB_URL;?>/productReturn">
                               <img src="<?php echo WEB_URL;?>/images/returnorder.png" width="90">
                               <div><?php $dbF->hardWords('Return');?></div>
                           </a>
                       </div>
                   <?php } ?>

                   <?php if($functions->developer_setting('defect_Product_from_client') == '1'){ ?>
                    <div class="col-sm-2 text-center padding-0">
                        <a href="<?php echo WEB_URL;?>/productDefect">
                            <img src="<?php echo WEB_URL;?>/images/defect.png" height="90" width="">
                            <div><?php $dbF->hardWords('Defect');?></div>
                        </a>
                    </div>
                    <?php } ?>

                   <!--<div class="col-sm-2 text-center padding-0">
                       <a href="<?php /*echo WEB_URL;*/?>/cartWishList.php">
                           <img src="<?php /*echo WEB_URL;*/?>/images/wishlish.png" width="90">
                           <div><?php /*$dbF->hardWords('Wish List');*/?></div>
                       </a>
                   </div>-->


                   <div class="col-sm-2 text-center padding-0">
                       <a href="<?php echo WEB_URL;?>/logout">
                           <img src="<?php echo WEB_URL;?>/images/logout.png" width="90">
                           <div><?php $dbF->hardWords('LogOut');?></div>
                       </a>
                   </div>

                   <div class="clearfix"></div>
                <?php
                    }else{
                ?>

                <?php
                        if($msg!=''){
                            echo "<div class='alert alert-success'>$msg</div>";
                        }
                        $webClass->webUserEdit($webClass->webUserId());
                    }
                ?>
               </div>
        </div>
    </div>
    <!--Inner Container Ends-->

<?php include("footer.php"); ?>