<?php
global $dbF;
global $db;
global $_e;
global $functions;
global $productClass;
global $webClass;
global $menuClass;
global $seo;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    
    <link rel="icon" href="<?php echo WEB_URL ?>/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="<?php echo WEB_URL ?>/favicon.ico" type="image/x-icon" />

    <?php //$functions->ourLogoSecurity(); ?>

<?php $cartInfo = $productClass->cartInfo(true);



// $dbF->prnt($seo);

// die;




 ?>
    <script type="text/javascript" src="<?php echo WEB_URL ?>/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo WEB_URL ?>/js/jquery_ui.js"></script>


<script type="text/javascript" defer="defer" src="<?php echo WEB_URL ?>/js/product.php"></script>
    <!--############################## CSS FILES ################################# -->


    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/assets/alertify/themes/alertify.core.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/hover.css" /> 
    <!-- <title>Lush Leather</title> -->

    <?php $webClass->AllSeoPrint(); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--Bootstrap css file-->
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/animate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/hover.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/mmenu.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/owl.theme.css">
    
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/vmenuModule.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEB_URL ?>/css/style.css">
    <!-- DESKTOP -->
    <link href="<?php echo WEB_URL ?>/css/style-desktop.css" rel="stylesheet" type="text/css" media="only screen and (min-width:979px) and (max-width:1280px)">
    <!-- TABLET -->
    <link href="<?php echo WEB_URL ?>/css/style-tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width:768px) and (max-width:978px)">
    <!-- MOBILE -->
    <link href="<?php echo WEB_URL ?>/css/style-mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width:461px) and (max-width:767px)">
    <!-- MOBILE SMALL-->
    <link href="<?php echo WEB_URL ?>/css/style-mobile-small.css" rel="stylesheet" type="text/css" media="only screen and (max-width:460px)"> 
    <script type="text/javascript" src="<?php echo WEB_URL ?>/js/js.cookie.min.js"></script>
    <script type="text/javascript" src="<?php echo WEB_URL ?>/js/flexmenu.min.js"></script>
    <?php echo $functions->ibms_setting('headScript'); ?>
    <?php $webClass->subscribeFormSubmit(); ?>
</head>

<body>

    <!--when add to cart , animation show...-->
<div id="cartLoading"></div>
<!--when add to cart , animation show End...-->




    <div class="main_container">
        <header>
            <div class="header_side">
                <div class="header_top fadeInLeft">
                <div class="standard">
                    <div class="whatsapp_contact">
                        <?php $box1 = $webClass->getBox('box1'); ?>
                        <a href="tel:<?php echo str_replace("-", "", $box1['linkText'])?>">                            
                            <i class="fab fa-whatsapp"></i>
                        <h5><?php echo $box1['heading'] ?>:<?php echo $box1['linkText'] ?></h5>
                        </a>
                    </div>
                    <!-- whatsapp close -->
                    <div class="mail">
                        <?php $box2 = $webClass->getBox('box2'); ?>
                       <a href="mailto:<?php echo $box2['linkText'] ?>">
                           <i class="far fa-envelope"></i>
                       <h5><?php echo $box2['linkText'] ?></h5>
                       </a>
                    </div>
                    <!-- mail close -->
                    <div class="top_links">
                        <?php echo $menuClass->main_menu('top_menu'); ?>
                    </div>
                    <!-- top-links close -->
                </div>
                <!-- standard close -->
                </div>
                <!-- header_top close -->
                <div class="header_bottom Wow fadeInDown">
                    <div class="standard">
                    <div class="social_icon">
                        <a href="<?php echo $functions->ibms_setting('Facebook'); ?>" target="_blank">
                            <div class="social fb hvr-pop"></div>
                            <!-- soc close -->
                        </a>
                        <a href="<?php echo $functions->ibms_setting('twitter'); ?>" target="_blank">
                            <div class="social tw hvr-pop"></div>
                            <!-- soc close -->
                        </a>
                        <a href="<?php echo $functions->ibms_setting('Instagram'); ?>" target="_blank">
                            <div class="social in hvr-pop"></div>
                            <!-- soc close -->
                        </a>
                        <a href="<?php echo $functions->ibms_setting('linkedIn'); ?>" target="_blank">
                            <div class="social ins hvr-pop"></div>
                            <!-- soc close -->
                        </a>
                    </div>
                    <!-- social close -->
                    <div class="logo">
                        <a href="<?php echo WEB_URL ?>">
                        <img src="<?php echo WEB_URL ?>/webImages/logo.png" alt="">
                        </a>
                    </div>
                    <!-- logo close -->
                    <div class="cart">
<a href="<?php echo WEB_URL."/cart" ?>">

                        <img src="webImages/cart.png" alt="">
           

                        <div class="cart_txt">
                            <h5>CART:</h5>
                            <div class="cart_txt_ cartItemNo">
                                <?php echo $cartInfo['qty']; ?>
                            </div>
                            <span>items</span> - 



                            <div class="cart_txt_2 cartPriceAjax" data-value="has">
                               

<?php echo $cartInfo['price']; ?>



<?php echo $cartInfo['symbol']; ?>                            
</div>
                        </div>
                        <!-- cart_txt close -->
                    </div>
                    </a>
                    <!-- cart close -->
                    </div>
                    <!-- standard close -->
                </div>
                <!-- header_bottom close -->
                <div class="header_bottom_ wow fadeInUp">
                    <div class="standard">
                    <div class="menu_side">
                        <img src="<?php echo WEB_URL ?>/webImages/12.png" alt="" width="25" height="20" title="menu">
                    </div><!-- menu-side close -->
                        <div class="nav_">
                        <ul>
                             <?php
                                    ##### RESPONSIVE MAIN MENU
                                    $css = false;
                                    $mainMenu = $menuClass->menuTypeSingle('main_menu');
                                    foreach ($mainMenu as $val) {
                                    $insideActive = false;
                                    $innerUl = '';
                                    $menuId = $val['id'];
                                    $text = ($val['name']);
                                    $link = $val['link'];
                                    $mainMenu2 = $menuClass->menuTypeSingle('main_menu', $menuId);
                                    if (!empty($mainMenu2)) {
                                    $innerUl .= '<ul>';
                                    foreach ($mainMenu2 as $val2) {
                                    $innerUl3 = '';
                                    $text = ($val2['name']);
                                    $menuId = $val2['id'];
                                    $link = $val2['link'];
                                    $mainMenu3 = $menuClass->menuTypeSingle('main_menu', $menuId);
                                    # count the inner level 3 lis
                                    $innerUl3count = ( $mainMenu3 == false ? 0 : count($mainMenu3) ) ;
                                    $innerUl3 .= ( $innerUl3count > 0 ) ? '<ul>' : '';
                                    if ( $innerUl3count > 0 ) {
                                    foreach ($mainMenu3 as $val3) {
                                    $innerUl4 = '';
                                    $text3       = ($val3['name']);
                                    $menuId3     = $val3['id'];
                                    $link3       = $val3['link'];
                                    $mainMenu4 = $menuClass->menuTypeSingle('main_menu', $menuId3);
                                    # count the inner level 3 lis
                                    $innerUl4count = ( $mainMenu4 == false ? 0 : count($mainMenu4) ) ;
                                    $innerUl4 .= ( $innerUl4count > 0 ) ? '<ul>' : '';
                                    if ( $innerUl4count > 0 ) {
                                    foreach ($mainMenu4 as $val4) {
                                    $text4       = ($val4['name']);
                                    $link4       = $val4['link'];
                                    $innerUl4 .= '<li><a href="' . $link4 . '">' . $text4 . '</a></li>';
                                    }}
                                    $innerUl4 .= ( $innerUl4count > 0 ) ? '</ul><!--3rd array End-->' : '';
                                    $innerUl3 .= '
                                    <li><a href="' . $link3 . '">' . $text3 . '</a>
                                    ' . $innerUl4 . '
                                    </li>';
                                    }
                                    }
                                    $innerUl3 .= ( $innerUl3count > 0 ) ? '</ul><!--3rd array End-->' : '';
                                    $innerUl .= '<li><a href="' . $link . '">' . $text . '</a>' . $innerUl3 . '</li>';
                                    }
                                    $innerUl .= "</ul><!--2nd array End-->";
                                    }
                                    $text = ($val['name']);
                                    $link = $val['link'];
                                    echo '<li><a href="' . $link . '">' . $text . '</a>' . $innerUl . '</li>';
                                    }
                                ?> 
                        </ul>
                    </div>
                    <!-- nav-side close --> 
                    <div class="search">


               




                        <form method="get" action="<?php echo WEB_URL; ?>/search.php">
                            <input type="text" name="s" class="txt_search" value="" placeholder="Search...">
                            <input type="submit" value class="search_btn">
                        </form>
                    </div>
                    <!-- search close-->
                    </div>
                    <!--standard close -->
                </div>
                <div class="header_bottom_1 Wow fadeInDown">
                    <div class="standard">
                        <div class="main_mmenu">
                        <div id="page">
                            <nav id="menu">
                <ul><li>

                 



                        <form class="search_2" action="<?php echo WEB_URL; ?>/search.php">
                            <input type="text" name="s" value="" placeholder="Search...">
                            <input type="submit" value class="search_btn">
                        </form>
                    </li>
                     <?php
                                    ##### RESPONSIVE MAIN MENU
                                    $css = false;
                                    $mainMenu = $menuClass->menuTypeSingle('main_menu');
                                    foreach ($mainMenu as $val) {
                                    $insideActive = false;
                                    $innerUl = '';
                                    $menuId = $val['id'];
                                    $text = ($val['name']);
                                    $link = $val['link'];
                                    $mainMenu2 = $menuClass->menuTypeSingle('main_menu', $menuId);
                                    if (!empty($mainMenu2)) {
                                    $innerUl .= '<ul>';
                                    foreach ($mainMenu2 as $val2) {
                                    $innerUl3 = '';
                                    $text = ($val2['name']);
                                    $menuId = $val2['id'];
                                    $link = $val2['link'];
                                    $mainMenu3 = $menuClass->menuTypeSingle('main_menu', $menuId);
                                    # count the inner level 3 lis
                                    $innerUl3count = ( $mainMenu3 == false ? 0 : count($mainMenu3) ) ;
                                    $innerUl3 .= ( $innerUl3count > 0 ) ? '<ul>' : '';
                                    if ( $innerUl3count > 0 ) {
                                    foreach ($mainMenu3 as $val3) {
                                    $innerUl4 = '';
                                    $text3       = ($val3['name']);
                                    $menuId3     = $val3['id'];
                                    $link3       = $val3['link'];
                                    $mainMenu4 = $menuClass->menuTypeSingle('main_menu', $menuId3);
                                    # count the inner level 3 lis
                                    $innerUl4count = ( $mainMenu4 == false ? 0 : count($mainMenu4) ) ;
                                    $innerUl4 .= ( $innerUl4count > 0 ) ? '<ul>' : '';
                                    if ( $innerUl4count > 0 ) {
                                    foreach ($mainMenu4 as $val4) {
                                    $text4       = ($val4['name']);
                                    $link4       = $val4['link'];
                                    $innerUl4 .= '<li><a href="' . $link4 . '">' . $text4 . '</a></li>';
                                    }}
                                    $innerUl4 .= ( $innerUl4count > 0 ) ? '</ul><!--3rd array End-->' : '';
                                    $innerUl3 .= '
                                    <li><a href="' . $link3 . '">' . $text3 . '</a>
                                    ' . $innerUl4 . '
                                    </li>';
                                    }
                                    }
                                    $innerUl3 .= ( $innerUl3count > 0 ) ? '</ul><!--3rd array End-->' : '';
                                    $innerUl .= '<li><a href="' . $link . '">' . $text . '</a>' . $innerUl3 . '</li>';
                                    }
                                    $innerUl .= "</ul><!--2nd array End-->";
                                    }
                                    $text = ($val['name']);
                                    $link = $val['link'];
                                    echo '<li><a href="' . $link . '">' . $text . '</a>' . $innerUl . '</li>';
                                    }
                                ?> 
                    
                </ul>
            </nav>
            <div class="menu_icn">
                <a href="#menu" class="menu_icn_">
                    <img src="webImages/12.png" alt="" width="25" height="20" title="menu">
                </a>
            </div>
            <!--menu_icn end here-->
        </div>
        <!-- page close -->
    </div>  
                        <div class="logo">
                        <a href="<?php echo WEB_URL ?>">
                        <img src="<?php echo WEB_URL ?>/webImages/logo.png" alt="">
                        </a>
                    </div>
                    <!-- logo close -->
                    <div class="cart">
                        <img src="<?php echo WEB_URL ?>/webImages/cart.png" alt="">
                        <span class="cartItemNo">    <?php echo $cartInfo['qty']; ?></span>
                        <div class="cart_txt">
                            <h5>CART:</h5>
                            <div class="cart_txt_ cartItemNo">
                                 <?php echo $cartInfo['qty']; ?>
                            </div>
                            <span>items - <?php echo $cartInfo['symbol']; ?></span> 
                            <div class="cart_txt_2 cartPriceAjax">
                              

<?php echo $cartInfo['price']; ?>
                            </div>
                        </div>
                        <!-- cart_txt close -->
                    </div>
                    <!-- cart close -->
                    </div>
                </div>
            </div>
            <!-- header_side close -->
             
        </header>
        <!-- header close -->
