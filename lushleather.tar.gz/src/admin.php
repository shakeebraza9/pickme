<?php
//integrate with Admin,, on ajax call axis from here,, to save admin secrets
//PENDING