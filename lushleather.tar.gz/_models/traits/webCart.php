<?php

//some webcart functions here,, becase of havy file size, webProduct_functions.php

trait webcart{

}