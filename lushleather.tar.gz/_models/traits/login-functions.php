<?php

 //Move to else Secret

 ##### /* assss */ ######
##### /* assss */ ######
//coment
//coment
   //coment
/* asdasd */
 /* asdasd */
 $code = ""; //asd
 $code = ""; //asd /* asdkja */ //as
 $code = ""; ###### s ###

 $name = str_replace("#", "", "#some");
 $url = "http://ggjg"; // 22 tet $comment asad aa A 522 as

 // ##### ttest

 /*  asda
     dasdas
     asdad
 */

function aaas(){

} // Foreach loop End

?>