<?php
///Move after New functions and setting to some Where else secret....
trait Encryption__
{
    // encode using in login function
    public function encode($value){}

    public function decode($value){}
}
?>