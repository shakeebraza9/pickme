<?php 

    global $dbF, $functions, $productClass, $_e;

?>

<!--  checkout offer modal -->



<div class="pop_side" style="display: none;">

    <div class="pop_close">

        <i class="far fa-times-circle"></i>

    </div>

    <!-- <div class="pop_side_top"> <i class="far fa-bell"></i> <?php $dbF->hardWords('Do not forget to buy to'); ?> -->
    <!-- <div class="number_side"><span>1</span>/2</div> -->

<!-- </div> -->

    <!-- pop_close close -->

    <div id="doNotForgetToBuy">



    </div>

    <!-- pop_slide close -->


<div class="pop_btn">
<div class="pop_btn1 hvr-pulse-grow active">
<!-- button -->
</div>
<!-- btn1 close -->
<div class="pop_btn2 hvr-pulse-grow active">
<!-- button -->
</div>
<!-- btn2 close -->
</div>
<!-- pop_btn close -->


</div>
<!-- pop_side close -->
