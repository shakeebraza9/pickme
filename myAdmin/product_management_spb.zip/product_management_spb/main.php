<?php ob_start(); ?>

Chose the options !@#$%;





<?php return ob_get_clean(); ?>