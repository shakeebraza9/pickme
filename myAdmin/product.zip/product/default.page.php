<?php ob_start();
echo "Default Page";
return ob_get_clean(); ?>