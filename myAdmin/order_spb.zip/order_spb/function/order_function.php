<?php

class stock_function extends object_class{
    function __construct()
    {
        parent::__construct('3');
    }
}
?>